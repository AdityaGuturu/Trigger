const express = require("express")
const db = require("./database")
const cors = require("cors")
const app = express()
app.use(express.json())
app.use(cors())
app.use(express.urlencoded({extended:false}))
app.get("/demo1",async(req,resp)=>{

    const connection = await db();
    const collection = connection.collection("toys");
    let data = await collection.find().toArray();
    resp.json(data)

})
app.get("/demo",async(req,resp)=>{

    const connection = await db();
    const collection = connection.collection("toys");
    let data = await collection.find().toArray();
    resp.json(data)

})

app.post("/input",async(req,resp)=>{
    const connection = await db();
    const collection = connection.collection("users");
    let data = await collection.insertOne(req.body)
})
app.listen(5000)